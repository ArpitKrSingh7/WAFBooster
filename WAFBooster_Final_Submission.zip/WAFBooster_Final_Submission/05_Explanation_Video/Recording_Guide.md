# Explanation video recording guide

The assignment requires every team member to speak on camera with their name and face clearly visible. Record in Zoom or a similar meeting tool, share the presentation and relevant source code, and cover the research question, WAFBooster pipeline, experimental setup, findings, limitations, and proposed improvements.

Suggested contribution order, matching the report and slides:

1. **Abdur Rahim (CS23I1019), slides 1–4:** research problem, WAF testbed, dataset generation, labels, and class imbalance.
2. **Faraz Nezami (CS23I1031), slides 5–8:** tokenizer, Word2Vec/ShadowCNN, learning-rate retuning, GRU generation, and the corrector bug and fix.
3. **Arpit Kumar Singh (CS23I1022), slides 9–14:** signature scoring and alignment, ModSecurity deployment, ablation, held-out results, residual bypass, limitations, and proposed production recommendations.

Each speaker should explain their design choices and be prepared to distinguish the original paper's method from the team's implementation, observations, and extensions. Save the finished recording as `05_Explanation_Video/Team_Explanation.mp4` (or another common video format) and replace the status note with the recording before uploading the final archive.
