# WAFBooster Final Submission

## Contents

- `01_Technical_Report/Technical_Report.pdf`: the team's research analysis, implementation, critical assessment, proposed extensions, results, citations, and contribution table. The LaTeX source is in `01_Technical_Report/Source/`.
- `02_Presentation/Presentation.pptx`: the 14-slide presentation. `Presentation_Handout.pdf` is its PDF preview.
- `03_Implementation/`: source code, execution README, Docker configuration, data, trained models, rules, results, and supplemental figures.
- `04_Assigned_Research_Paper/Assigned_Research_Paper.pdf`: the paper analyzed by the team.
- `05_Explanation_Video/Team_Explanation.mp4`: the recorded team explanation.

## Run the implementation

See `03_Implementation/README.md` for dependencies, Docker setup, pipeline order, and generated artifacts.
