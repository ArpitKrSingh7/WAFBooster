# WAFBooster Final Submission

## Contents

- `01_Technical_Report/Technical_Report.pdf`: the team's analysis, reproduction, critical assessment, proposed extensions, results, citations, and contribution table. The LaTeX source is in `01_Technical_Report/Source/`.
- `02_Presentation/Presentation.pptx`: the 14-slide presentation. `Presentation_Handout.pdf` is a PDF preview of those slides.
- `03_Implementation/`: source code, README execution instructions, Docker configuration, CSIC input data, processed CSVs, trained model artifacts, ModSecurity rules, results, and supplementary figures.
- `04_Assigned_Research_Paper/Assigned_Research_Paper.pdf`: the paper analyzed by the team.
- `05_Explanation_Video/`: recording requirements and a team speaking plan.

## Video status

No explanation video was present in the workspace when this archive was prepared. The video is a required deliverable and is **not included**. The team must record and add it before final submission. Follow `05_Explanation_Video/Recording_Guide.md`; every member should appear with their name and face visible while explaining their contribution.

## Run the implementation

See `03_Implementation/README.md` for dependencies, Docker setup, pipeline order, and generated artifacts.
